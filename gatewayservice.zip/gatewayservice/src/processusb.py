import secureusbdb as secureDatabase
import GatewayInitialization as initialization
import GatewayCommunication as validationService
import messaging as messagingService
import messageCreation as messageUtil
import tamperImage as imageutil
import ImageUtil as imageData
import hashUtil as hashutil
import uuid
import random
import json
import requests
from PIL import Image


def getData(url,data):
    print(data)
    print(url)
    headers = {'Content-type': 'application/json', 'Accept': 'text/plain'}
    r = requests.post(url, data, headers=headers)
	
    return r.content

def process():
    # define tempfile
    tmpImageFile="currentidentity.png"
	
    # print image file name
    print(tmpImageFile)
	
    # Get USB Informmation
    deviceUUID, publickey = secureDatabase.getUSBDetails(tmpImageFile)
	
    #print("Creates session profile")
    # Create session information
    alignList  = ['V','H']    

    sessionData = {}
    sessionData["type"]= '1'
    sessionData["sessionid"]= str(uuid.uuid1())
    sessionData['deviceid']=deviceUUID
    sessionData['align'] = random.choice(alignList)
    sessionData['startFrom']=random.randint(1, 380)
    sessionData['tamperPixel']=random.randint(1, 19)
    sessionjson=json.dumps(sessionData)

    print("Created session Profile")
    sessionID=sessionData["sessionid"]
    alignment=sessionData['align']
    startFrom = sessionData['startFrom']
    tamperPixels=sessionData['tamperPixel']
    print("Received Session ID: " + sessionID)
    print("... tampering Alignment: " + alignment)
    print("... Start From : " + str(startFrom))
    print("... Tamper pixek : " + str(tamperPixels))
    
    
    print("Creates the session by submitting request to authentication service.")
    createSessionURL="https://arcane-chamber-85852.herokuapp.com/session/create"
    getData(createSessionURL,sessionjson)
    print("Session created")
    
    print("Start Local processing")
    # tamper the image and get hashcode
    print(tmpImageFile)
    im = Image.open(tmpImageFile)
    pixels = list(im.getdata())
    width, height = im.size
    
    print("Tamper the iemage based on session profile")
    if alignment == 'V' :
        print('vertical')
        tamperedImageData = imageutil.vertical(pixels, startFrom, width, height)
    else:
        print('horizontal')
        tamperedImageData = imageutil.horizontal(pixels, startFrom, tamperPixels, width, height)
        
    print("Save the tampered image to file")
    # save Tampered Data to file
    tamperedFileName = 'tamperedusbdrive.png'
    imageData.saveImage(tamperedFileName, tamperedImageData,width, height)

    print("Generate SHA512 hashcode for the image")
    # Create Image hash Code in database
    sha512hashCode = hashutil.getsha512hashForFile(tamperedFileName)
	
    # Create Session Topic
    sessionTopic = sessionID
	
    print("Submit SHA512 hashcode for validation")
    # create Validation message
    validationMessageJSON = messageUtil.getValidationMessage(sessionID,sha512hashCode)
	
    print("Display Result")
    # Send the Hash code
    validationSessionURL="https://arcane-chamber-85852.herokuapp.com/session/validate"
    return getData(validationSessionURL,validationMessageJSON)
    


