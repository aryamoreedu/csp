#!/usr/bin/env python
# -*- coding: utf-8 -*-
#
#  usbdevicedb.py
#  
#  Copyright 2019 nex53212 <nex53212@NEX53212-WX-1>
#  
#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.
#  
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#  
#  You should have received a copy of the GNU General Public License
#  along with this program; if not, write to the Free Software
#  Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston,
#  MA 02110-1301, USA.
#  
#  

import psycopg2
from psycopg2 import pool
import json
import keysutil

def getUUID():
	
	returnID = ""
	
	try:
		# Read config database
		with open('devicedbconfig.json') as json_data:
			deviceDBConfig = json.load(json_data)
        
			postgreSQL_pool = psycopg2.pool.SimpleConnectionPool(1, deviceDBConfig['max'],user = deviceDBConfig['user'],
                                              password = deviceDBConfig['password'],
                                              host = deviceDBConfig['host'],
                                              port = deviceDBConfig['port'],
                                              database = deviceDBConfig['database'])
        
			if(postgreSQL_pool):
				ps_connection  = postgreSQL_pool.getconn()
				getUUIDSQL="select uuid from accountdevice where deviceid=9"
				
				deviceID=9
				cursor = ps_connection.cursor()
				cursor.execute(getUUIDSQL)
				row = cursor.fetchone()
            
				if row is not None:
					returnID =row[0]
            
	except (Exception, psycopg2.DatabaseError) as error :
		print ("Error while creating PostgreSQL table", error)

	finally:
		#closing database connection.
		if(ps_connection):
			cursor.close()
			ps_connection.close()
			print("PostgreSQL connection is closed")
	return returnID 

def main(args):
	print(getUUID(9))
	return 0

if __name__ == '__main__':
    import sys
    sys.exit(main(sys.argv))
