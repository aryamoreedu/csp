def horizontal(imageData, startFrom, tamperPixels, imageWidth, imageHeigth):
    startPos= (startFrom-1)*imageWidth
    numberOfPixelsTotamper = imageWidth * tamperPixels
    endPos = startPos + numberOfPixelsTotamper

    for i in range(startPos, endPos) :
        imageData[i]=(0,0,0)

    return imageData

def vertical(imageData, startFromCol, imageWidth, imageHeight):    
    numberOfRows = imageHeight

    startRow = 0
    tamperpixelWidth = imageWidth - startFromCol
    currentCol = startFromCol
    currentRow = startRow

    while currentRow < numberOfRows:
        currentCol = ( currentRow * imageWidth ) + startFromCol
        endCol = currentCol + tamperpixelWidth

        for j in range ( currentCol, endCol ): 
            imageData[j]=(0,0,0)

        currentRow = currentRow + 1

    return imageData
