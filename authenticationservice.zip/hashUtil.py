import hashlib

def getsha512hashForFile(filename):
    return hashlib.sha512(open(filename,'rb').read()).hexdigest()


    
