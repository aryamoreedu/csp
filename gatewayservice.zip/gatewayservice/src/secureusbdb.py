#!/usr/bin/env python
import aes_encryptionUtil as aesencryptionUtil
import passwordUtil as pwdUtil
import keyCreationUtil as keyUtil
import sqlite3

from pysqlcipher import dbapi2 as sqlite

def generatePassword(pwdFileName,dbPassword):
     print(dbPassword)
     public_Key, private_Key = keyUtil.generateKey(1024)
     dbsharedKey = str(public_Key[0]) + str(public_Key[1])
     savePassword(pwdFileName,dbsharedKey, dbPassword)
    
def savePassword(pwdFileName,dbsharedKey, dbPassword):
     passwordFile = open(pwdFileName,'w') 
     passwordFile.write(dbsharedKey +'\n')
     passwordFile.write(aesencryptionUtil.AESCipher(dbsharedKey).encrypt(dbPassword))
     passwordFile.close()
    
def getPassword(pwdFileName):
    
    with open(pwdFileName,'r') as pwdFile :
        pwdArray = []
        for lineData in pwdFile :
            pwdArray.append(lineData)
    
    sharedPassword = pwdArray[0].rstrip('\n')
    encryptedcontent = pwdArray[1]
    
    returnPassword = aesencryptionUtil.AESCipher(sharedPassword).decrypt(encryptedcontent)
    
    savePassword(pwdFileName,sharedPassword, returnPassword)
    
    return returnPassword
    

def executeCreateSQL(dbfilename,key):
    createTableSQL = 'CREATE TABLE IF NOT EXISTS truststore(deviceuuid TEXT, publickey TEXT,imageidentity BLOB, createdon TIMESTAMP DEFAULT CURRENT_TIMESTAMP)'
    
    dbconnection = sqlite.connect(dbfilename)
    dbcursor = dbconnection.cursor()
    dbKey = "PRAGMA key='" + key + "'"
    dbcursor.execute(dbKey)
    dbcursor.execute(createTableSQL)
    dbconnection.commit()
    dbcursor.close()

def insertgatewaydetails(usbdriveID, publickey, imageFile):
    
    with open(imageFile, 'rb') as input_file:
        ablob = input_file.read()
        sql = 'INSERT INTO truststore(deviceuuid, publickey, imageidentity) VALUES (?, ?, ?);'
        
        # get Password
        pwdFileName="usbtruststore.pwd"
        key = getPassword(pwdFileName)
        
        # get Gateway Data
        deviceUUID=usbdriveID
        publickey=publickey
        
        dbfilename = "usbtruststore.db"
        dbconnection = sqlite.connect(dbfilename)
        dbcursor = dbconnection.cursor()
        dbKey = "PRAGMA key='" + key + "'"
        dbcursor.execute(dbKey)
        dbcursor.execute(sql,[usbdriveID, publickey, sqlite3.Binary(ablob)])
        dbconnection.commit()

def registerUSB(usbdriveID, publickey, imageFile):
    
    # Create Password
    pwdFileName="usbtruststore.pwd"
    password = pwdUtil.mkpassword (40)
    print(password)
    generatePassword(pwdFileName,password)
    
    # get Password
    key = getPassword(pwdFileName)
    print(key)
    
    dbfilename = "usbtruststore.db"
    
    # create tables
    executeCreateSQL(dbfilename,key)
    
    # Insert Data into securedb
    insertgatewaydetails(usbdriveID, publickey, imageFile)
    
def getUSBDetails(imageFile):
    
    sql = "SELECT deviceuuid, publickey, imageidentity FROM truststore"
    print(sql)

    # get Password
    pwdFileName="/media/pi/LAPROTECT/data/usbtruststore.pwd"
    print(pwdFileName)
    
    key = getPassword(pwdFileName)
    print(key)
    
    # Get Device Information
    dbfilename = "/media/pi/LAPROTECT/data/usbtruststore.db"
    dbconnection = sqlite.connect(dbfilename)
    dbcursor = dbconnection.cursor()
    dbKey = "PRAGMA key='" + key + "'"
    dbcursor.execute(dbKey)
    dbcursor.execute(sql)
    deviceuuid, publickey, imageidentity = dbcursor.fetchone()
    dbconnection.close
    
    print('Got Device Information')
    
    # Save Image File
    with open(imageFile, 'wb') as output_file:
        output_file.write(imageidentity)
        
    return (deviceuuid, publickey)
    
    
