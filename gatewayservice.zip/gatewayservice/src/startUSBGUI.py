#!/usr/bin/python

import Tkinter
import tkMessageBox
import diskUtil as diskUtility
import processusb as usbController
import json

top = Tkinter.Tk()
top.title("Passwordless Authentication")
top.minsize(480,320)
screensize="480x320"
top.geometry(screensize)

frame = Tkinter.Frame(top)
frame.pack()

# Code to add widgets will go here...
pImage=Tkinter.PhotoImage(file="creditcard.png")
labelImage = Tkinter.Label( frame, image=pImage, width=128,height=128)
labelImage.pack()

label1 = Tkinter.Label( frame, text="")
label1.pack()

label3 = Tkinter.Label( frame, text="Welcome to the Credit Card Authentication Demo")
label3.pack()

label4 = Tkinter.Label( frame, text="")
label4.pack()

def processUSBDrive():
   isRightDisk = diskUtility.checkfordisk()
   if isRightDisk == 1:
      tkMessageBox.showinfo( "Information", "Please insert the Valid Credit Card.")
   else:
      processUSBDataJSON = usbController.process()
      print(processUSBDataJSON)
      processUSBData = json.loads(processUSBDataJSON)
      if processUSBData['status'] == 4:
          tkMessageBox.showinfo( "Information", "Credit Card is successfully validated.")
      else:
         tkMessageBox.showinfo( "Error", "Credit card validation failed.")
         

insertUSBbutton = Tkinter.Button(frame, text='Please insert the Credit Card and Press this button', width=300, command=processUSBDrive)

insertUSBbutton.pack()

label2 = Tkinter.Label( frame, text="")
label2.pack()

exitbutton = Tkinter.Button(frame, 
                   text="Exit",  width=300,
                   command=quit)
exitbutton.pack(side=Tkinter.RIGHT)

top.mainloop()
