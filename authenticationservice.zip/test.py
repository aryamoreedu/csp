print("hello world")

