python secureusbdb.py
