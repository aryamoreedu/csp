import paho.mqtt.client as mqtt
import json

def send(topicname,topicmessage):
	
	returnValue = "failure"
	
	# Read config database
	with open('mqttconfig.json') as json_data:
		mqttConfig = json.load(json_data)
		
	client = mqtt.Client()
	client.username_pw_set(mqttConfig['user'], mqttConfig['password'])
	client.connect(mqttConfig['hostname'],int(mqttConfig['port']),60)
	client.publish(topicname, topicmessage);
	client.disconnect();
	
	returnValue = "success"
	
	return returnValue
	
def init(uuid):
	
	topicname = uuid + "_INIT"
	topicmessage = "INIT" 
	
	return send(topicname,topicmessage)

	
