import psycopg2
from psycopg2 import pool
import json

def createSession(sessionID):
	
    returnstatus =  "error"
    
    try:
        # Read config database
        with open('devicedbconfig.json') as json_data:
            deviceDBConfig = json.load(json_data)
        
        postgreSQL_pool = psycopg2.pool.SimpleConnectionPool(1, deviceDBConfig['max'],user = deviceDBConfig['user'],
                                              password = deviceDBConfig['password'],
                                              host = deviceDBConfig['host'],
                                              port = deviceDBConfig['port'],
                                              database = deviceDBConfig['database'])
        
        if(postgreSQL_pool):
            ps_connection  = postgreSQL_pool.getconn()
            
            if(ps_connection):
                insertDEVICESQL = 'insert into sessiondetails(sessionid) values (\''+sessionID+'\')'
                print(insertDEVICESQL)

                cursor = ps_connection.cursor()
                cursor.execute(insertDEVICESQL)
                ps_connection.commit()
              
                returnstatus =  "success"

    except (Exception, psycopg2.DatabaseError) as error :
        print ("Error while creating PostgreSQL table", error)

    finally:
        #closing database connection.
        if(ps_connection):
            cursor.close()
            ps_connection.close()
        print("PostgreSQL connection is closed")

    returndata = {}
    returndata['status'] =  returnstatus

    return json.dumps(returndata)
	
def complete(sessionid, hashcode):
    returnstatus =  "error"
    
    try:
        # Read config database
        with open('devicedbconfig.json') as json_data:
            deviceDBConfig = json.load(json_data)
        
        postgreSQL_pool = psycopg2.pool.SimpleConnectionPool(1, deviceDBConfig['max'],user = deviceDBConfig['user'],
                                              password = deviceDBConfig['password'],
                                              host = deviceDBConfig['host'],
                                              port = deviceDBConfig['port'],
                                              database = deviceDBConfig['database'])
        
        if(postgreSQL_pool):
            ps_connection  = postgreSQL_pool.getconn()
            
            if(ps_connection):
                updateSessionSQL = 'UPDATE sessiondetails SET hashcode = \'' +  hashcode + '\', currentstatus=2 where sessionid=\''+ sessionid + '\''
                print(updateSessionSQL)

                cursor = ps_connection.cursor()
                cursor.execute(updateSessionSQL)
                ps_connection.commit()
              
                returnstatus =  "success"

    except (Exception, psycopg2.DatabaseError) as error :
        print ("Error while creating PostgreSQL table", error)

    finally:
        #closing database connection.
        if(ps_connection):
            cursor.close()
            ps_connection.close()
        print("PostgreSQL connection is closed")

    returndata = {}
    returndata['status'] =  returnstatus

    return json.dumps(returndata)

def verify(sessionid, usbhashcode):
    returnstatus =  "failed"
    returnMessage = "Authentication failed"
    
    try:
        # Read config database
        with open('devicedbconfig.json') as json_data:
            deviceDBConfig = json.load(json_data)
        
        postgreSQL_pool = psycopg2.pool.SimpleConnectionPool(1, deviceDBConfig['max'],user = deviceDBConfig['user'],
                                              password = deviceDBConfig['password'],
                                              host = deviceDBConfig['host'],
                                              port = deviceDBConfig['port'],
                                              database = deviceDBConfig['database'])
        
        if(postgreSQL_pool):
            ps_connection  = postgreSQL_pool.getconn()
            
            if(ps_connection):
                selectSQL = 'select hashcode, currentstatus from sessiondetails where sessionid=\''+ sessionid + '\''
                print(selectSQL)

                cursor = ps_connection.cursor()
                cursor.execute(selectSQL)

                row = cursor.fetchone()
            
                if row is not None:
                    hashcode = row[0]
                    currentstatus = row[1]

                if hashcode == usbhashcode:
                    currentstatus = 4
                    returnstatus = "success"
                    returnMessage = "Successful Authentication."
                else:
                    currentstatus = 3 #Failed

                if currentstatus == 3:
                        delete(sessionid)
                        
        returnstatus =  currentstatus

    except (Exception, psycopg2.DatabaseError) as error :
        print ("Error while creating PostgreSQL table", error)

    finally:
        #closing database connection.
        if(ps_connection):
            cursor.close()
            ps_connection.close()
        print("PostgreSQL connection is closed")

    returndata = {}
    returndata['status'] =  returnstatus
    returndata['message'] =  returnMessage

    return json.dumps(returndata)

def delete(sessionid):
    returnstatus =  "error"
    
    try:
        # Read config database
        with open('devicedbconfig.json') as json_data:
            deviceDBConfig = json.load(json_data)
        
        postgreSQL_pool = psycopg2.pool.SimpleConnectionPool(1, deviceDBConfig['max'],user = deviceDBConfig['user'],
                                              password = deviceDBConfig['password'],
                                              host = deviceDBConfig['host'],
                                              port = deviceDBConfig['port'],
                                              database = deviceDBConfig['database'])
        
        if(postgreSQL_pool):
            ps_connection  = postgreSQL_pool.getconn()
            
            if(ps_connection):
                deleteSQL = 'delete from sessiondetails where sessionid=\''+ sessionid + '\''
                print(deleteSQL)

                cursor = ps_connection.cursor()
                cursor.execute(deleteSQL)
                ps_connection.commit()
              
                returnstatus =  "success"

    except (Exception, psycopg2.DatabaseError) as error :
        print ("Error while creating PostgreSQL table", error)

    finally:
        #closing database connection.
        if(ps_connection):
            cursor.close()
            ps_connection.close()
        print("PostgreSQL connection is closed")

    returndata = {}
    returndata['status'] =  returnstatus

    return json.dumps(returndata)
