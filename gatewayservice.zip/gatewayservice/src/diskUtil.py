import os

def checkfordisk():
    returnValue = 0
	
    try: 
        checkForAuthDisk = os.listdir("/media/pi")
        if "LAPROTECT" in checkForAuthDisk:
            disks=os.listdir("/media/pi/LAPROTECT/data") 
            if "usbtruststore.db" in disks:
                returnValue = 2
        else:
            returnValue = 1
	
    except:
        pass
          
    return returnValue
