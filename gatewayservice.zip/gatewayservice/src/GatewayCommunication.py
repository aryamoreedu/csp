import paho.mqtt.client as mqtt
import os
import time
import json
import messaging as messagingService
import messageCreation as messageUtil

mqttc = mqtt.Client()
hashcode =""
sessionID =""
isAuthenticationComplete=0
authenticationstatus="Error"
authenticationMessage="Error during authentication."

# Define event callbacks
def on_connect(client, userdata, flags, rc):
    print("rc: " + str(rc))

def on_message(client, obj, msg):
    print(msg.topic + " " + str(msg.qos) + " " + str(msg.payload))
    
    sessionData = json.loads(str(msg.payload))
    messageSessionID=sessionData["sessionid"]
    statusID = sessionData["status"]
	
    if messageSessionID == sessionID:
	if statusID == "3":
	    isAuthenticationComplete=1
	elif statusID == "4":
	    authenticationstatus="success"
	    authenticationMessage="Authentication Succeeded."
	    isAuthenticationComplete=1

def on_publish(client, obj, mid):
    print("mid: " + str(mid))

def on_subscribe(client, obj, mid, granted_qos):
    print("Subscribed: " + str(mid) + " " + str(granted_qos))

def on_log(client, obj, level, string):
    print(string)

def start(gtwysessionID, gtwayHashCode):
    mqttc.username_pw_set("goophtrv","xTc25f8DMZ-g")
    mqttc.connect("m15.cloudmqtt.com", 12297)
	
    sessionID = gtwysessionID
    hashcode = gtwayHashCode

    # Create Topic Name
    topicName = sessionID
	
    # Start subscribe, with QoS level 0
    mqttc.subscribe(topicName, 0)
	
    rc=0
    mins=0

    # Loop until we reach 5 minutes running
    while (mins <= 5) and (rc==0) and (isAuthenticationComplete==0):

        # create Validation message
	validationMessageJSON = messageUtil.getValidationMessage(sessionID,hashcode)
		
	# Send the Hash code
	messagingService.send("SESSION",validationMessageJSON)
		
	# Sleep for a minute
	time.sleep(60)

	# Increment the minute total
	mins += 1
		
	rc = mqttc.loop()
		
    returnValue={}
    returnValue["status"]=authenticationstatus
    returnValue["message"]=authenticationMessage
	
    return json.dumps(returnValue)
