import json

def createInitMessage(deviceUUID):
	initMessageDtls ={}
	initMessageDtls["type"]=0
	initMessageDtls["deviceid"]=deviceUUID
	
	return json.dumps(initMessageDtls)

def getValidationMessage(sesssionID, usbhashcode):
	validationMessageDtls ={}
	validationMessageDtls["type"]=0
	validationMessageDtls["sessionid"]=sesssionID
	validationMessageDtls["usbhashcode"]=usbhashcode
	
	return json.dumps(validationMessageDtls)
