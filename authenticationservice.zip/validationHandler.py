import usbsessiondb as session
import json

def handle(sessionData):

    # get Data
    sessionData = json.loads(sessionData)
    
    # get Session ID
    sessionID = sessionData['sessionid']

    # get Hash Code
    usbhashcode = sessionData['usbhashcode']
    
    status = session.verify(sessionID, usbhashcode)

    return status
    
