import paho.mqtt.client as mqtt
import os
import time

mqttc = mqtt.Client()
isGatewayInitilized =0
sessionID =""
alignment="V"
startPos=0
tamperPixels=0

# Define event callbacks
def on_connect(client, userdata, flags, rc):
    print("rc: " + str(rc))

def on_message(client, obj, msg):
    print(msg.topic + " " + str(msg.qos) + " " + str(msg.payload))
    
    # get Data
    sessionData = json.loads(sessionData)
    sessionID = sessionData['sessionid']
    alignment =  sessionData['align']
    startPos = int( sessionData['startFrom'] )
    tamperPixels = int( sessionData['tamperPixel'] )
    
    isGatewayInitilized = 1

def on_publish(client, obj, mid):
    print("mid: " + str(mid))

def on_subscribe(client, obj, mid, granted_qos):
    print("Subscribed: " + str(mid) + " " + str(granted_qos))

def on_log(client, obj, level, string):
    print(string)

def start(deviceID):
	mqttc.username_pw_set("goophtrv","xTc25f8DMZ-g")
	mqttc.connect("m15.cloudmqtt.com", 12297)

	# Create Topic Name
	topicName = deviceID +"_CLIENT"
	print(topicName)
	
	# Start subscribe, with QoS level 0
	mqttc.subscribe(topicName, 0)
	
	rc=0
	mins=0
	# Loop until we reach 5 minutes running
	while (mins <= 5) and (rc==0) and (isGatewayInitilized == 0):
                  
		# Sleep for a minute
		time.sleep(60)

		# Increment the minute total
		mins += 1
		rc = mqttc.loop()
		
	return (sessionID, alignment, startPos, tamperPixels)
