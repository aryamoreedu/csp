import psycopg2
from psycopg2 import pool
import json

def getUSBDeviceDetails(deviceID):
	
    identityID=""
    privateauthcertificate=""
    
    try:
        # Read config database
        with open('devicedbconfig.json') as json_data:
            deviceDBConfig = json.load(json_data)
        
        postgreSQL_pool = psycopg2.pool.SimpleConnectionPool(1, deviceDBConfig['max'],user = deviceDBConfig['user'],
                                              password = deviceDBConfig['password'],
                                              host = deviceDBConfig['host'],
                                              port = deviceDBConfig['port'],
                                              database = deviceDBConfig['database'])
        
        if(postgreSQL_pool):
            ps_connection  = postgreSQL_pool.getconn()
            
            if(ps_connection):
                selectSQL = 'select identityid, privateauthcertificate from accountdevice where uuid = \'' + deviceID + '\''
                print(selectSQL)

                cursor = ps_connection.cursor()
                cursor.execute(selectSQL)
                row = cursor.fetchone()
                identityID = row[0]
                privateauthcertificate = row[1]
              
                returnstatus =  "success"

    except (Exception, psycopg2.DatabaseError) as error :
        print ("Error while creating PostgreSQL table", error)

    finally:
        #closing database connection.
        if(ps_connection):
            cursor.close()
            ps_connection.close()
        print("PostgreSQL connection is closed")

    returndata = {}
    returndata['status'] =  returnstatus

    return (identityID, privateauthcertificate)
