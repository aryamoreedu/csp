from PIL import Image

def getData(fileName):
    im = Image.open(fileName)
    pixels = list(im.getdata())
    width, height = im.size

    return (width,height,pixels)


def saveImage(fileName,pixelData,width,height):
    im = Image.new('RGB', (width, height))
    im.putdata(pixelData)
    im.save(fileName)
