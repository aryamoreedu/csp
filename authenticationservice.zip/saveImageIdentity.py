import cloudinary.uploader
import cloudinary
import cloudinary.api
from PIL import Image
import urllib.request

# Initiate cloudinary sdk
cloudinary.config(
cloud_name = 'dql7hawul',  
api_key = '848631785853839',  
api_secret = '9-xjiq66FSg_b6C_NEqu-t3Sd2Y'  
)

def save(filename):
    # Upload an image 
    return cloudinary.uploader.upload(filename)

def getImage(identityID, tmpFileName):
    urllib.request.urlretrieve(identityID,tmpFileName)
  #  img_data = requests.get(identityID).content
   # with open(tmpFileName, 'wb') as handler:
    #    handler.write(img_data)

