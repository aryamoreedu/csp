from Crypto.PublicKey import RSA
import json

def getKeys():
    private_key = RSA.generate(1024)
    public_key = private_key.publickey()
    strpubkey = public_key.exportKey(format='PEM')
    strprivatekey = private_key.exportKey(format='PEM')
    
    data = {}
    data['private'] =  strprivatekey.decode('utf-8')
    data['public'] =  strpubkey.decode('utf-8')
    #jsonkey = json.dumps(data)

    return data

#print(getKeys())
