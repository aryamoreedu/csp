

# listen to topic on UUID_CLIENT till 5 minutes or till we recieve the status
