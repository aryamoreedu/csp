#foo.py
import os
import time
import processusb as usbController

print("Please insert usb drive..")
isCheckDiskInserted=0
while True:
    try: 
        checkForAuthDisk = os.listdir("/media/pi")
        if isCheckDiskInserted == 0 :
            if "LAPROTECT" in checkForAuthDisk:
                print('LAProcteccion usb detected')
                print('Get list of directory')
                disks=os.listdir("/media/pi/LAPROTECT/data") 
                if "usbtruststore.db" in disks:
                    print("Truststore Found")
                    isCheckDiskInserted=1 
                    usbController.process()
            else:
                #print("Disk Demoved")
                isCheckDiskInserted=0 
    except:
          pass
    time.sleep(0.5) 
