import secureusbdb as secureDatabase
import GatewayInitialization as initialization
import GatewayCommunication as validationService
import messaging as messagingService
import messageCreation as messageUtil

def process():
    # define tempfile
    tmpImageFile="currentidentity.png"
	
    # print image file name
    print(tmpImageFile)
	
    # Get USB Informmation
    deviceUUID, publickey = secureDatabase.getUSBDetails(tmpImageFile)
	
    # create INIT message
    initMessageJSON = messageUtil.(deviceUUID)
    print(initMessageJSON)
	
    # Trigger the Initialization
    messagingService.send("SESSION",initMessageJSON)
	
    # listen to uuid_client topic
    sessionID, alignment, startFrom, tamperPixels = initialization.start(deviceUUID)
    print("Received Session ID: " + sessionID)
    print("... tampering Alignment: " + alignment)
    print("... Start From : " + str(startFrom))
    print("... Tamper pixek : " + str(tamperPixels))
    
    # tamper the image and get hashcode
    im = Image.open(tmpImageFile)
    pixels = list(im.getdata())
    width, height = im.size
    
    if alignment == 'V' :
        print('vertical')
        tamperedImageData = imageutil.vertical(pixels, startFrom, width, height)
    else:
        print('horizontal')
        tamperedImageData = imageutil.horizontal(pixels, startFrom, tamperPixels, width, height)
        
    # save Tampered Data to file
    tamperedFileName = 'tamperedusbdrive.png'
    imageData.saveImage(tamperedFileName, tamperedImageData,width, height)

    # Create Image hash Code in database
    sha512hashCode = hashutil.getsha512hashForFile(tamperedFileName)
	
    # Create Session Topic
    sessionTopic = sessionID
	
    # create Validation message
    validationMessageJSON = messageUtil.getValidationMessage(sessionID,sha512hashCode)
	
    # Send the Hash code
    messagingService.send("SESSION",validationMessageJSON)
	
    #
    print(validationService.start(sessionID, sha512hashCode))
