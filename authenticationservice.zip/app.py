from flask import Flask
from flask import request
from flask import Response

import json 

import gatewayregistration as gtwyRegistration
import usbdriveregistration as usbdrvregistration
import sessionHandler as sessionhandler
import validationHandler as validationHandler
import usbdevicedb as usbdb
import messaging as messageService

app = Flask(__name__)

@app.route('/authenticate')
def authenticate():
    return "success"


@app.route('/register/storage', methods=['POST'])
def registerstorage():
    deviceDetailsData = request.data
    deviceDetailsDictionary =  json.loads(deviceDetailsData)
    responseData = usbdrvregistration.registerUSBDrive(deviceDetailsDictionary)

    resp = Response(responseData, status=201, mimetype='application/json')
    
    return resp

@app.route('/register/gateway', methods=['POST'])
def registergateway():
    deviceDetailsData = request.data
    deviceDetailsDictionary =  json.loads(deviceDetailsData)
    responseData = gtwyRegistration.registerGateway(deviceDetailsDictionary)

    resp = Response(responseData, status=201, mimetype='application/json')
    
    return resp

@app.route('/register/mobile')
def registercontroller():
    #keys = keysutil.getKeys()
    return ""

@app.route('/register/initiate', methods=['POST'])
def initiate():
#	deviceDetailsData = request.data
#	deviceDetailsDictionary =  json.loads(deviceDetailsData)
	usbuuid = usbdb.getUUID()
	returnStatus = "failure"
	returnMessage = "Unable to initiate the authentication process."
	
	if len(usbuuid.strip()) > 0 :
		messageService.init(usbuuid)
		returnStatus = "success"
		returnMessage = "Authentication process initiated."
		
	responseData ={}
	responseData["status"]=returnStatus
	responseData["message"]= returnMessage
	
	responseDataJSon = json.dumps(responseData)
	
	resp = Response(responseDataJSon, status=200, mimetype='application/json')
	
	return resp

@app.route('/session/create', methods=['POST'])
def createsession():
    sessionDetailsData = request.data
    sessionhandler.handle(sessionDetailsData)

    responseData ={}
    responseData["status"]="success"
    responseData["message"]= "Session is successfully created."

    responseDataJSon = json.dumps(responseData)
	
    resp = Response(responseDataJSon, status=204, mimetype='application/json')

    return resp

@app.route('/session/validate', methods=['POST'])
def validatesession():
    sessionDetailsData = request.data
    statusJSON = validationHandler.handle(sessionDetailsData)

    statusDict =  json.loads(statusJSON)

    if statusDict["status"] == "failed":
        resp = Response(statusJSON, status=401, mimetype='application/json')
    else:
        resp = Response(statusJSON, status=200, mimetype='application/json')

    return resp

@app.route('/')
def default():
    return "Hello!"

if __name__ == '__main__':
    app.run()
