import psycopg2
from psycopg2 import pool
import json
import keysutil

def registerGateway(devicedetails):
    publickey =  ""
    returnstatus =  "failed"
    
    try:
        # Read config database
        with open('devicedbconfig.json') as json_data:
            deviceDBConfig = json.load(json_data)
        
        postgreSQL_pool = psycopg2.pool.SimpleConnectionPool(1, deviceDBConfig['max'],user = deviceDBConfig['user'],
                                              password = deviceDBConfig['password'],
                                              host = deviceDBConfig['host'],
                                              port = deviceDBConfig['port'],
                                              database = deviceDBConfig['database'])
        
        if(postgreSQL_pool):
            ps_connection  = postgreSQL_pool.getconn()
            keys = keysutil.getKeys()
            
            if(ps_connection):
                insertDEVICESQL = 'INSERT INTO gatewaydevice(devicename, installedlongitude, installedlatitude, uuid, activestatus, communicationchannel, identityid, privateauthcertificate, sourceip )'
                insertDEVICESQL = insertDEVICESQL + ' values '
                insertDEVICESQL = insertDEVICESQL + '(\''+ devicedetails['devicename'] + '\','
                insertDEVICESQL = insertDEVICESQL + str(devicedetails['installedlongitude']) + ','
                insertDEVICESQL = insertDEVICESQL + str(devicedetails['installedlatitude']) + ','
                insertDEVICESQL = insertDEVICESQL + '\''+ devicedetails['uuid'] + '\','
                insertDEVICESQL = insertDEVICESQL + '1,'
                insertDEVICESQL = insertDEVICESQL + '\'9495005752\','
                insertDEVICESQL = insertDEVICESQL + '\'' + devicedetails['identityid'] + '\','
                insertDEVICESQL = insertDEVICESQL + '\'' + keys['private'] + '\','
                insertDEVICESQL = insertDEVICESQL + '\'' + devicedetails['sourceip'] + '\') returning deviceid'
                print(insertDEVICESQL)

                cursor = ps_connection.cursor()
                cursor.execute(insertDEVICESQL)
                ps_connection.commit()

                publickey =  keys['public']
                returnstatus =  "success"

    except (Exception, psycopg2.DatabaseError) as error :
        print ("Error while creating PostgreSQL table", error)

    finally:
        #closing database connection.
        if(ps_connection):
            cursor.close()
            ps_connection.close()
        print("PostgreSQL connection is closed")

    returndata = {}
    returndata['key'] =  publickey
    returndata['status'] =  returnstatus

    return json.dumps(returndata)

if __name__ == '__main__':
    deviceDetails = {}
    deviceDetails["devicename"] =  "gateway-001"
    deviceDetails["installedlongitude"] =  "121"
    deviceDetails["installedlatitude"] = "122"
    deviceDetails["uuid"] = "001"
    deviceDetails["activestatus"] = "active"
    deviceDetails["identityid"] = "1112344"
    deviceDetails["sourceip"] = "127.0.0.1"

   # jsonData = json.dumps(deviceDetails)
    
    print(deviceDetails)

    registerGateway(deviceDetails)
