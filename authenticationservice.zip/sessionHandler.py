import usbsessiondb as session
import hashUtil as hashutil
import tamperImage as imageutil
import ImageUtil as imageData
import usbdeviceauthdb as deviceauthdb
import saveImageIdentity as imageID
import json
from PIL import Image

def handle(sessionData):

    # get Data
    sessionData = json.loads(sessionData)
    
    # get Session ID
    sessionID = sessionData['sessionid']
    print(sessionID)
    
    # Create Session in Database with status as Authentication in progress
    session.createSession(sessionID)

    # Get Image for device
    deviceID = sessionData['deviceid']
    identityID, privateauthcertificate = deviceauthdb.getUSBDeviceDetails(deviceID)

    imageURL = 'https://res.cloudinary.com/dql7hawul/image/upload/v1550541863/' +identityID
    print(imageURL)

    tempFileName = 'tempusbdrive.png'
    imageID.getImage(imageURL,tempFileName)

    im = Image.open(tempFileName)
    pixels = list(im.getdata())
    width, height = im.size

    print(width)
    
    # Tamper image based on quote
    alignment =  sessionData['align']
    startFrom = int( sessionData['startFrom'] )
    tamperPixels = int( sessionData['tamperPixel'] )
    
    if alignment == 'V' :
        print('vertical')
        tamperedImageData = imageutil.vertical(pixels, startFrom, width, height)
    else:
        print('horizontal')
        tamperedImageData = imageutil.horizontal(pixels, startFrom, tamperPixels, width, height)

    # save Tampered Data to file
    tamperedFileName = 'tamperedusbdrive.png'
    imageData.saveImage(tamperedFileName, tamperedImageData,width, height)
        
    # Create Image hash Code in database
    md5hashCode = hashutil.getsha512hashForFile(tamperedFileName)

    # update hash code in the database with status Ready
    session.complete(sessionID, md5hashCode)

    return md5hashCode

if __name__ == '__main__':
    sessionData = '{"type":"1", "align": "V", "sessionid": "de7161c4-f045-4440-ac16-8f07692803d8", "deviceid": "9", "tamperPixel": 19, "startFrom": 256}'
    print(handle(sessionData))
